package com.stock.spring.repository;

import com.stock.spring.entity.Predict;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PredictRepository extends JpaRepository<Predict, Long> {
    List<Predict> findByCompany(String company);
}
