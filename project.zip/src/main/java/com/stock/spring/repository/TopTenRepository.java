// TopTenRepository.java
package com.stock.spring.repository;

import com.stock.spring.entity.TopTen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TopTenRepository extends JpaRepository<TopTen, Long> {
    List<TopTen> findTop10ByOrderByResultDesc();
}
