package com.stock.spring.repository;

import com.stock.spring.entity.TotalPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TotalPriceRepository extends JpaRepository<TotalPrice, Long> {
    // 특정 메서드가 필요하다면 여기에 작성
}
