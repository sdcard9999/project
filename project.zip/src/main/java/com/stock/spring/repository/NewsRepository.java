package com.stock.spring.repository;

import com.stock.spring.entity.News;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NewsRepository extends JpaRepository<News, Long> {
    // 추가적인 검색 메서드가 필요하다면 여기에 작성
}
