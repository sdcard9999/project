package com.stock.spring.model;

public class Company {
    private String corpCode;
    private String corpName;
    private String stockCode;
    private String modifyDate;

    public Company(String corpCode, String corpName, String stockCode, String modifyDate) {
        this.corpCode = corpCode;
        this.corpName = corpName;
        this.stockCode = stockCode;
        this.modifyDate = modifyDate;
    }

    // Getters and Setters

    public String getCorpCode() {
        return corpCode;
    }

    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }

    public String getCorpName() {
        return corpName;
    }

    public void setCorpName(String corpName) {
        this.corpName = corpName;
    }

    public String getStockCode() {
        return stockCode;
    }

    public void setStockCode(String stockCode) {
        this.stockCode = stockCode;
    }

    public String getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }
}
