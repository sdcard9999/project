package com.stock.spring.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoryDTO {
    private String company;
    private String headline;
    private String text;
    private String url;
    private String news_info;
    private String time; // 주의: 필드명을 "time"으로 소문자로 일치시킴
}
