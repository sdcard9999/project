package com.stock.spring.dto;

import com.stock.spring.entity.Price; // Price 엔티티가 존재하는 패키지를 맞게 import 해주세요
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PriceDTO {
    private Long id;
    private String company;
    private LocalDate date;
    private double price;

    // Price 엔티티를 인자로 받는 생성자 추가
    public PriceDTO(Price price) {
        this.id = price.getId();
        this.company = price.getCompany();
        this.date = price.getDate();
        this.price = price.getPrice();
    }
}
