package com.stock.spring.Service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
public class HistoryService {
    private static final String HISTORY_API_URL = "https://api.example.com/history"; // API URL 변경 필요

    public Map<String, Object> getHistoryData(String corpCode) {
        RestTemplate restTemplate = new RestTemplate();
        String url = HISTORY_API_URL + "?corpCode=" + corpCode;
        return restTemplate.getForObject(url, Map.class);
    }
}
