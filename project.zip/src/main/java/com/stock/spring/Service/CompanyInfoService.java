package com.stock.spring.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import java.util.Map;

@Service
public class CompanyInfoService {

    private static final String API_URL = "https://opendart.fss.or.kr/api/company.json";

    private final RestTemplate restTemplate;
    private final String apiKey;

    public CompanyInfoService(RestTemplate restTemplate, @Value("${openapi.dart.api_key}") String apiKey) {
        this.restTemplate = restTemplate;
        this.apiKey = apiKey;
    }

    public Map<String, Object> getCompanyInfo(String corpCode) {
        String url = API_URL + "?crtfc_key=" + apiKey + "&corp_code=" + corpCode;

        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody(); // JSON 데이터를 Map 형식으로 반환
        } else {
            throw new RuntimeException("API 호출 실패: " + response.getStatusCode());
        }
    }
}
