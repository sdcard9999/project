// TopTenService.java
package com.stock.spring.Service;

import com.stock.spring.dto.TopTenDTO;
import com.stock.spring.entity.TopTen;
import com.stock.spring.repository.TopTenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TopTenService {

    @Autowired
    private TopTenRepository topTenRepository;

    private static final String TOP_TEN_API_URL = "https://api.example.com/topten"; // 실제 API URL로 변경 필요

    public List<TopTenDTO> getTopTen() {
        // Step 1: 외부 API에서 데이터 가져오기
        RestTemplate restTemplate = new RestTemplate();
        List<Map<String, Object>> apiData = restTemplate.getForObject(TOP_TEN_API_URL, List.class);

        // Step 2: 가져온 데이터를 가공 및 데이터베이스에서 추가 정보 결합
        return apiData.stream()
                .map(data -> {
                    Long id = Long.parseLong(data.get("id").toString()); // API 응답에서 ID 가져오기
                    Optional<TopTen> optionalTopTen = topTenRepository.findById(id); // DB에서 ID로 조회

                    if (optionalTopTen.isPresent()) {
                        TopTen topTen = optionalTopTen.get();
                        return new TopTenDTO(topTen.getId(), topTen.getCompany(), topTen.getResult()); // getCompany로 수정
                    } else {
                        return new TopTenDTO(id, data.get("name").toString(), Double.parseDouble(data.get("result").toString()));
                    }
                })
                .collect(Collectors.toList());
    }
}
