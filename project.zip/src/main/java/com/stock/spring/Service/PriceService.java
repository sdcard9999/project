package com.stock.spring.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.stock.spring.dto.PriceDTO;
import com.stock.spring.repository.PriceRepository;

import java.util.Optional;

@Service
public class PriceService {

    @Autowired
    private PriceRepository priceRepository;

    public Page<PriceDTO> getAllPrices(Pageable pageable) {
        return priceRepository.findAll(pageable)
                .map(price -> new PriceDTO(price)); // Price를 PriceDTO로 변환
    }

    public Optional<PriceDTO> findById(Long id) {
        return priceRepository.findById(id)
                .map(price -> new PriceDTO(price)); // Price를 PriceDTO로 변환
    }
}
