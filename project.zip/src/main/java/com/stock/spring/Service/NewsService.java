package com.stock.spring.Service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
public class NewsService {
    private static final String NEWS_API_URL = "https://api.example.com/news"; // API URL 변경 필요

    public Map<String, Object> getNewsData(String corpCode) {
        RestTemplate restTemplate = new RestTemplate();
        String url = NEWS_API_URL + "?corpCode=" + corpCode;
        return restTemplate.getForObject(url, Map.class);
    }
}