package com.stock.spring.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.stock.spring.model.Company;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class CompanyCodeService {

    private static final String API_URL = "https://opendart.fss.or.kr/api/corpCode.xml";

    private final RestTemplate restTemplate;
    private final String apiKey;

    public CompanyCodeService(RestTemplate restTemplate, @Value("${openapi.dart.api_key}") String apiKey) {
        this.restTemplate = restTemplate;
        this.apiKey = apiKey;
    }

    public List<Company> downloadAndParseCorpCode() throws Exception {
        List<Company> companyList = new ArrayList<>();
        String url = API_URL + "?crtfc_key=" + apiKey;

        Resource resource = restTemplate.getForObject(url, Resource.class);
        if (resource != null) {
            try (InputStream is = resource.getInputStream();
                 ZipInputStream zis = new ZipInputStream(is)) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    if (entry.getName().endsWith(".xml")) {
                        Path tempFile = Files.createTempFile("corpCode", ".xml");
                        Files.copy(zis, tempFile, StandardCopyOption.REPLACE_EXISTING);
                        companyList = parseXmlFile(tempFile);
                        Files.deleteIfExists(tempFile);
                    }
                }
            }
        }
        return companyList;
    }

    private List<Company> parseXmlFile(Path xmlFilePath) throws Exception {
        List<Company> companies = new ArrayList<>();
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(Files.newInputStream(xmlFilePath));

        doc.getDocumentElement().normalize();
        NodeList nodeList = doc.getElementsByTagName("list");

        for (int i = 0; i < nodeList.getLength(); i++) {
            Element element = (Element) nodeList.item(i);

            String corpCode = element.getElementsByTagName("corp_code").item(0).getTextContent();
            String corpName = element.getElementsByTagName("corp_name").item(0).getTextContent();
            String stockCode = element.getElementsByTagName("stock_code").item(0).getTextContent();
            String modifyDate = element.getElementsByTagName("modify_date").item(0).getTextContent();

            companies.add(new Company(corpCode, corpName, stockCode, modifyDate));
        }

        return companies;
    }
}
