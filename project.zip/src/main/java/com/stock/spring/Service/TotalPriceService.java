package com.stock.spring.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.stock.spring.dto.PriceDTO;
import com.stock.spring.dto.TotalPriceDTO;

import java.util.Map;
import java.util.Optional;

@Service
public class TotalPriceService {
    private static final String TOTAL_PRICE_API_URL = "https://api.example.com/totalprice"; // API URL 변경 필요

    public Map<String, Object> getTotalPriceData(String corpCode) {
        RestTemplate restTemplate = new RestTemplate();
        String url = TOTAL_PRICE_API_URL + "?corpCode=" + corpCode;
        return restTemplate.getForObject(url, Map.class);
    }


    public Optional<PriceDTO> findById(Long id) {
        return priceRepository.findById(id)
                .map(price -> new PriceDTO(price)); // Price를 PriceDTO로 변환
    }


	public Page<TotalPriceDTO> getAllTotalPrices(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

}
