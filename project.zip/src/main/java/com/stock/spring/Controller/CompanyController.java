package com.stock.spring.Controller;

import com.stock.spring.model.Company;
import com.stock.spring.Service.CompanyCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CompanyController {

    private final CompanyCodeService companyCodeService;

    @Autowired
    public CompanyController(CompanyCodeService companyCodeService) {
        this.companyCodeService = companyCodeService;
    }

    @GetMapping("/company-codes")
    public List<Company> getCompanyCodes() {
        try {
            // 외부 API로부터 데이터를 받아와서 반환
            return companyCodeService.downloadAndParseCorpCode();
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch company codes", e);
        }
    }
}