package com.stock.spring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stock.spring.Service.PriceService;
import com.stock.spring.dto.PriceDTO;

import java.util.Optional;

@RestController
@RequestMapping("/api/prices")
public class PriceController {

    @Autowired
    private PriceService priceService;

    @GetMapping
    public Page<PriceDTO> getAllPrices(Pageable pageable) {
        return priceService.getAllPrices(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PriceDTO> getPriceById(@PathVariable Long id) {
        Optional<PriceDTO> price = priceService.findById(id);
        return price.map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
    }
}
