package com.stock.spring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stock.spring.Service.PredictionService;
import com.stock.spring.dto.PredictDTO;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/predictions")
public class PredictionController {

    @Autowired
    private PredictionService predictService;

    @GetMapping
    public List<PredictDTO> getAllPredictions() {
        return predictService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PredictDTO> getPredictionById(@PathVariable Long id) {
        Optional<PredictDTO> prediction = predictService.findById(id);
        return prediction.map(ResponseEntity::ok)
                         .orElse(ResponseEntity.notFound().build());
    }
}
