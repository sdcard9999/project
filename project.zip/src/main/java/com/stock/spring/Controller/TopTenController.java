
package com.stock.spring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.stock.spring.Service.TopTenService;
import com.stock.spring.dto.TopTenDTO;

import java.util.List;

@RestController
@RequestMapping("/api/topten")
public class TopTenController {

    @Autowired
    private TopTenService topTenService;

    @GetMapping
    public List<TopTenDTO> getTopTen() {
        return topTenService.getTopTen();
    }
}
