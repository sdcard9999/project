package com.stock.spring.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stock.spring.Service.HistoryService;
import com.stock.spring.dto.HistoryDTO;

@RestController
@RequestMapping("/api/histories")
public class HistoryController {

    @Autowired
    private HistoryService historyService;

    @GetMapping
    public Page<HistoryDTO> getAllHistories(Pageable pageable) {
        return historyService.getAllHistories(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistoryDTO> getHistoryById(@PathVariable Long id) {
        Optional<HistoryDTO> history = historyService.findById(id);
        return history.map(ResponseEntity::ok)
                      .orElse(ResponseEntity.notFound().build());
    }
}
