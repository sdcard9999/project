package com.stock.spring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stock.spring.Service.TotalPriceService;
import com.stock.spring.dto.TotalPriceDTO;

import java.util.Optional;

@RestController
@RequestMapping("/api/totalprices")
public class TotalPriceController {

    @Autowired
    private TotalPriceService totalPriceService;

    @GetMapping
    public Page<TotalPriceDTO> getAllTotalPrices(Pageable pageable) {
        return totalPriceService.getAllTotalPrices(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TotalPriceDTO> getTotalPriceById(@PathVariable Long id) {
        Optional<TotalPriceDTO> totalPrice = totalPriceService.findById(id);
        return totalPrice.map(ResponseEntity::ok)
                         .orElse(ResponseEntity.notFound().build()); //로직 추가 요망
    }
}
