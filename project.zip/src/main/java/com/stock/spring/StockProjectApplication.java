package com.stock.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockProjectApplication{

    public static void main(String[] args) {
        SpringApplication.run(StockProjectApplication.class, args);
    }
}